#ifndef DEFINES_H_
#define DEFINES_H_

enum InputCommands
{
	CREATE                = 0,
	COPY_CONSTRUCT        = 1,
	COPY_ASSIGN    		  = 2,
	SUM_ARRAY_DATA        = 3,
	INCR_ARRAY_DATA_VALUE = 4
};

#endif /* DEFINES_H_ */
