#ifndef ORGANISM_H
#define ORGANISM_H

#include <string>

class Organism {
	
};

#endif // !ORGANISM_H

